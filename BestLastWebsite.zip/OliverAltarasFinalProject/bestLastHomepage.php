<!doctype html>
<html lang="en">
  <head>
  
  <?php
	
		//Creating a database connection
		$dbhost = "localhost";
		$dbuser = "root";
		$dbpassword = "";
		$dbname = "bestlastproducts";

		$connection = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);
		
		//Testing if connection works
		if(mysqli_connect_errno()){
			die("DB connection failed: " .
				mysqli_connect_error() .
					" (" . mysqli_connect_errno() . ")"
					);
		}

		if (!$connection)
			{
				die('Could not connect: ' . mysqli_error());
			}
		
		
		//Creating variables for all the items on each element from the database
			$sql = "SELECT * FROM items WHERE id='1';";
			$result = mysqli_query($connection, $sql);
			$row1 = mysqli_fetch_assoc($result);
			
			$sql = "SELECT * FROM items WHERE id='2';";
			$result = mysqli_query($connection, $sql);
			$row2 = mysqli_fetch_assoc($result);
			
			$sql = "SELECT * FROM items WHERE id='3';";
			$result = mysqli_query($connection, $sql);
			$row3 = mysqli_fetch_assoc($result);
			
			$sql = "SELECT * FROM items WHERE id='4';";
			$result = mysqli_query($connection, $sql);
			$row4 = mysqli_fetch_assoc($result);
			
			$sql = "SELECT * FROM items WHERE id='5';";
			$result = mysqli_query($connection, $sql);
			$row5 = mysqli_fetch_assoc($result);
			
			

		
		// Close database connection
			mysqli_close($connection);
	?>
	<link rel="icon" href="brandImages/icon.png" height="16">
	<!-- Icon library -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>Best Last - Homepage</title>
	
	<style>
	
	input::-webkit-outer-spin-button,
	input::-webkit-inner-spin-button {
	-webkit-appearance: none;
	margin: 0;
	}
	
	input[type=number] {
	-moz-appearance: textfield;
	}
	
	.selectQty {
	padding: 5px;
	font-size: 25px;
	color: #28a745;
	border: 6px solid #28a745;	
	}
	
	.table {
	color: white;
	}
	
	.clearButton {
	border: solid white 0.8px;
	padding: 5px;
	border-radius: 100px;
	background: #28a745;
	display: inline-block;
	color: white;
	}
	
	.navbar {
	opacity: 0.95;
	padding-right: 50px;
	}
	
	.btn {
	background-color: white;
	border: #28a745 solid;
	color: #28a745;
	}
	
	.jumbotron {
	background-color: white; 
	border: dashed 20px #28a745; 
	color: black;
	}
	
	.fa {
	color: white;
	padding: 10px;
	font-size: 30px;
	text-align: center;
	text-decoration: none;
	margin: 5px 2px;
	}
	
	.price {
	color: green;
	font-size: 20px;
	font-weight: bold;
	}
	
	.mediaType {
	color: gray;
	}
	
	.carousel-item {
	border-top: dashed #2F4F4F;
	border-bottom: dashed #2F4F4F;
	}
	
	#talkToUs {padding-right: 100px;}
	
	ul.inlinelist li {display: inline;}
	
	.jumboButton {
	background-color: green; 
	color: white;
	border: solid white 0.8px;
	}
	
	#secret {
	border: solid 2px #28a745; 
	color: green;
	padding: 6px;
	}
	
	#modalInfo {color: #28a745;}
	
	#bodySpecs {background-color: #2F4F4F;}
	
	#footerPadding {
	padding-top: 70px;
	padding-bottom: 20px;
	}
	
	#totalModal {
	background: #28a745;
	padding: 10px;
	color: white;
	text-align: center;
	}
	
	mark {
	background-color: black;
	color: white;
	}
	
	footer {
	border-top: solid 5px #2F4F4F;
	padding-top: 30px;
	background-color: #28a745;
	color: white;
	}

	</style>

  </head>
  <body onload="randomise()" id="bodySpecs">
  
  <!-- Here the navbar starts -->
  
<nav class="navbar navbar-expand-lg navbar-dark bg-success sticky-top">
	<a href="bestLastHomepage.php"><img src="brandImages/logoBL.png" height="80" alt="Logo - Best Last" title="bestlast.com"></a>
		<a id="aboutUs" class="navbar-brand" href="bestLastAboutUs.php">&nbsp; About us</a>
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		  </button>

		  <div class="collapse navbar-collapse" id="navbarSupportedContent">
			<ul class="navbar-nav mr-auto">
			   <li class="nav-item">
        <a id="talkToUs" data-toggle="modal" data-target=".bd-example-modal-sm1" class="nav-link" href="#">Talk to us</a>
				</li>
				<li>
				<button id="tree" onclick="goGreen()" class="btn btn-outline-success my-2 my-sm-0" title="Environmental campaign" type="submit">Go full green!</button>
				</li>
			</ul>
			<form class="form-inline my-2 my-lg-0">
			  <input id="username" class="form-control mr-sm-2" type="email" name="email" placeholder="Username" aria-label="Username" required>
			  <input id="password" class="form-control mr-sm-2" type="password" name="password" placeholder="Password" aria-label="Password" required>
			  <button id="logbut" onclick="login()" class="btn btn-outline-success my-2 my-sm-0" type="submit">Log in</button>
			</form>
		  </div>
</nav>
				<!-- modal 1 code below -->
				<div class="modal fade bd-example-modal-sm1" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
				  <div class="modal-dialog modal-sm">
					<div class="modal-content">
						<img src="brandImages/icon.png" class="img-fluid">
						<h3 id="modalInfo" align="center">&nbsp;bestlast.com </h3>
						<p>&nbsp; Phone: 01 123 4567</P>
						<p>&nbsp; E-mail: info@bestlast.com</p>
						<p>&nbsp; Address: 12 Central Street, Dublin 89</p>
						<p>&nbsp; Dublin, Ireland</p>
					</div>
				  </div>
				</div>
				<!-- modal ends -->
				
	<!-- Here the jumbotron starts -->

<div class="jumbotron">
	  <h1 id="jumbotitle" class="display-4" align="center">Show some love to the outcast!</h1>
	  <p class="lead" align="center">Welcome to the online shop where underrated masterpieces get a second chance</p><br>
	  <p class="lead" align="center">
    <a class="btn btn-primary btn-lg jumboButton" onclick="guessing()" id="guessBut" href="" role="button">Guess a number and get a treat</a>
  </p>
</div>
				

	<!-- Here the carousel starts -->

<div class="container">
	<div id="carouselExampleIndicators" class="carousel slide container" data-ride="carousel">
	<ol class="carousel-indicators">
			<li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
			<li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
			<li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
			<li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
		  </ol>
			<div class="carousel-inner" align="center">
				<!--1st item-->
				<div id="slide1" class="carousel-item">
					  <a href="#productMrBadGuy"><img class="d-block w-100" src="carouselImages/caroBadGuy.png" alt="Freddie Mercury - Living on my Own" title="Buy Mr. Bad Guy"></a>
						<div class="carousel-caption d-none d-md-block">
					<h5><mark>Mr. Bad Guy - Freddie Mercury</mark></h5>
					<p><mark>Because even royals can't have it all</mark></p>
						</div>
				</div>
				<!--2nd item-->
				<div id="slide2" class="carousel-item">
					  <a href="#productET"><img class="d-block w-100" src="carouselImages/caroET.png" alt="E.T. game homescreen" title="Buy ET"></a>
						<div class="carousel-caption d-none d-md-block">
					<h5><mark>E.T. - Atari</mark></h5>
					<p><mark>This 8-bit E.T. might not be the one you fell in love with, but he still needs to go home</mark></p>
						</div>
				</div>
				<!--3rd item-->
				<div id="slide3" class="carousel-item">
					  <a href="#productWaterworld"><img class="d-block w-100" src="carouselImages/caroWaterworld.png" alt="Kevin Costner in Waterworld" title="Buy Waterworld"></a>
						<div class="carousel-caption d-none d-md-block">
					<h5><mark>Waterworld</mark></h5>
					<p><mark>Kevin Costner lashes out at this classic's box-office performance</mark></p>
						</div>
				</div>
				 <!--4th item-->
				<div id="slide4" class="carousel-item">
					  <a href="#productCasualVacancy"><img class="d-block w-100" src="carouselImages/caroJK.png" alt="JK Rowling holding a copy of 'The Casual Vacancy'" title="Buy The Casual Vacancy"></a>
						<div class="carousel-caption d-none d-md-block">
					<h5><mark>The Casual Vacancy</mark></h5>
					<p><mark>Magic spells weren't enough for JK's career out of Hogwarts</mark></p>
						</div>
				</div>
			</div>
	<a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
		<span class="carousel-control-prev-icon" aria-hidden="true"></span>
		<span class="sr-only">Previous</span>
	</a>
	<a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
		<span class="carousel-control-next-icon" aria-hidden="true"></span>
		<span class="sr-only">Next</span>
	</a>
	</div>
	<!--Here products start-->
	<div class="row">
		
			<div class="col-lg-12">
				<br>
				<br>
			</div>
			
		<div id="productList" class="card-deck">
					<!--1st product-->
					 <div id="productET" class="card">
						<img class="card-img-top" src="productImages/etCard.png" alt="E.T. Game cover" title="E.T. Game cover" >
						<div class="card-body">
						  <h5 class="card-title"><?php echo $row1['product'];?></h5>
						  <p class="card-text">We won't lie to you: this game is not the most fun ever. But, for all the wrong reasons, this 8-bit adaptation of the classic Spielberg film has become legendary. And it is a must-have for any game collector.</p>
						  <p class="mediaType">Media: <?php echo $row1['media'];?></p>
						  <p class="price">Price: €<?php echo $row1['price'];?></p>
						  <br><br><br>
								<select class="selectQty" id="dropd1">
								  <option disabled selected>Quantity</option>
								  <option value="1">1</option>
								  <option value="2">2</option>
								  <option value="3">3</option>
								</select>
						  <a onclick="buy1()" href="#purchase" class="btn btn-primary btn-lg jumboButton" role="button">Add to cart</a>					  
						</div>
					 </div>
					 <!--2nd product-->
					 <div id="productWaterworld" class="card">
						<img class="card-img-top" src="productImages/waterworldCard.png" alt="Waterworld movie poster" title="Waterworld movie poster">
						<div class="card-body">
						  <h5 class="card-title"><?php echo $row2['product'];?></h5>
						  <p class="card-text">This is the quintessential Hollywood flop. Its ingredients include a massive budget, a troubled production, an A-class star and, alas, a disappointing box-office. But, in this age of environmental concern, this Mad Max-wannabe flick remains an interesting cautionary tale.</p>
						  <p class="mediaType">Media: <?php echo $row2['media'];?></p>
						  <p class="price">Price: €<?php echo $row2['price'];?></p>
						  <br>
						  <select class="selectQty" id="dropd2">
								  <option disabled selected value="">Quantity</option>
								  <option value="1">1</option>
								  <option value="2">2</option>
								  <option value="3">3</option>
								</select>
						  <a onclick="buy2()" href="#purchase" class="btn btn-primary btn-lg jumboButton" role="button">Add to cart</a>
						</div>
					 </div>
					 <!--3rd product-->
					 <div class="card">
						<img class="card-img-top" src="productImages/rookieBlueCard.jpg" alt="Rookie Blue 1st season DVD cover" title="Rookie Blue 1st season DVD cover">
						<div class="card-body">
						  <h5 class="card-title"><?php echo $row3['product'];?></h5>
						  <p class="card-text">The only difference between this and other American crime TV shows is that this one is actually Canadian. However, it is interesting to see how many of the genre's tropes fit into the less violent setting of Toronto.</p>
						  <p class="mediaType">Media: <?php echo $row3['media'];?></p>
						  <p class="price">Price: €<?php echo $row3['price'];?></p>
						  <br><br><br><br>
						  <select class="selectQty" id="dropd3">
								  <option disabled selected value="">Quantity</option>
								  <option value="1">1</option>
								  <option value="2">2</option>
								  <option value="3">3</option>
								</select>
						  <a onclick="buy3()" href="#purchase" class="btn btn-primary btn-lg jumboButton" role="button">Add to cart</a>
						</div>
					 </div>
		</div>
				
			<div class="col-lg-12">
				<br>
			</div>
		
		<!--2nd deck-->
		<div class="card-deck">
					<!--1st product-->
					 <div id="productCasualVacancy" class="card">
						<img class="card-img-top" src="productImages/casualVacancyCard.png" alt="The Casual Vacancy book cover" title="The Casual Vacancy book cover">
						<div class="card-body">
						  <h5 class="card-title"><?php echo $row4['product'];?></h5>
						  <p class="card-text">The mother of Harry Potter and his gang gave it a go in the adult genre - sadly, she failed to recapture the magical (pun intended) spell of her beloved book series. But we at bestlast.com believe that this novel's muggle setting has an appeal of its own.</p>
						  <p class="mediaType">Media: <?php echo $row4['media'];?></p>
						  <p class="price">Price: €<?php echo $row4['price'];?></p>
						  <br>
						  <select class="selectQty" id="dropd4">
								  <option disabled selected value="">Quantity</option>
								  <option value="1">1</option>
								  <option value="2">2</option>
								  <option value="3">3</option>
								</select>
						  <a onclick="buy4()" href="#purchase" class="btn btn-primary btn-lg jumboButton" role="button">Add to cart</a>
						</div>
					 </div>
					 <!--2nd product-->
					 <div id="productMrBadGuy" class="card">
						<img class="card-img-top" src="productImages/badGuyCard.jpg" alt="Mr. Bad Guy LP cover" title="Mr. Bad Guy LP cover">
						<div class="card-body">
						  <h5 class="card-title"><?php echo $row5['product'];?></h5>
						  <p class="card-text">Freddie Mercury's only solo album was far from being a massive hit, barely reaching the top 20 charts in a handful of countries. Yet, songs like "I was born to love you" and "Living on my own" make <i>Mr. Bad Guy</i> well worth your time.
						  </p>
						  <p class="mediaType">Media: <?php echo $row5['media'];?></p>
						  <p class="price">Price: €<?php echo $row5['price'];?></p>
						  <br><br>
								<select class="selectQty" id="dropd5">
								  <option disabled selected value="">Quantity</option>
								  <option value="1">1</option>
								  <option value="2">2</option>
								  <option value="3">3</option>
								</select>
						  <a onclick="buy5()" href="#purchase" class="btn btn-primary btn-lg jumboButton" role="button">Add to cart</a>
						</div>
					 </div>
					 <!--3rd product-->
					 <div class="card">
						<img class="card-img-top" src="brandImages/nextBLCard.png" alt="Next Best Last product" title="What's the next product?">
						<div class="card-body">
						  <h5 class="card-title">What's next?</h5>
						  <p class="card-text">We are always willing to listen to your opinion (unless it is <i>too</i> silly). Tell us what forsaken treasure you'd like to see for sale on our website and we will make sure to consider it!</p>
						  						 
						  <form>
							<textarea class="form-control" id="comments" rows="3" placeholder="Leave us a suggestion, kind shopper!"></textarea><br>
							<button onclick="comment()" class="btn btn-outline-success my-2 my-sm-0" type="submit">Send</button>
							<br>
							<br>
							<p><b>All suggestions:</b></p>
							<p><i id="suggestions">No suggestions yet</i></p>
						  </form>						  
						</div>
					 </div>
		</div>
		
		<div class="col-lg-12">
				<br>
			</div>
		
		
	</div>
	
	
	
	
</div>

<!--purchase div-->
	<div class="container" id="purchase">
	<br>
	<h2 class="text-center text-white">Your purchase</h2>
	<br><hr>
		<table class="table table-borderless">
		  <tr>
			<th>Product</th>
			<th>Quantity</th>
			<th>Price €</th>
		  </tr>
		  <tr>
			<td>E.T. the Extra-Terrestrial (cartridge)</td>
			<td id="amount1">0</td>
			<td id="total1">0</td>
			<td><button onclick="clearItem1()" class="clearButton" type="button">Clear</button></td>
		  </tr>
		  <tr>
			<td>Waterworld (VHS)</td>
			<td id="amount2">0</td>
			<td id="total2">0</td>
			<td><button onclick="clearItem2()" class="clearButton" type="button">Clear</button></td>
		  </tr>
		  <tr>
			<td>Rookie Blue (DVD)</td>
			<td id="amount3">0</td>
			<td id="total3">0</td>
			<td><button onclick="clearItem3()" class="clearButton" type="button">Clear</button></td>
		  </tr>
		  <tr>
			<td>The Casual Vacancy (book)</td>
			<td id="amount4">0</td>
			<td id="total4">0</td>
			<td><button onclick="clearItem4()" class="clearButton" type="button">Clear</button></td>
		  </tr>
		  <tr>
			<td>Mr. Bad Guy (LP)</td>
			<td id="amount5">0</td>
			<td id="total5">0</td>
			<td><button onclick="clearItem5()" class="clearButton" type="button">Clear</button></td>
		  </tr>
		  <tr>
			<th></th>
			<th>Total</th>
			<th><b id="totalTotal"></b></th>
		  </tr>
		</table><hr>
		<p align="right">
		<button type="button" class="btn btn-primary jumboButton" data-toggle="modal" data-target="#paymentModal">Check out</button>
		</p>
		
						<!-- Payment modal -->
							<div class="modal fade" id="paymentModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
							  <div class="modal-dialog modal-dialog-centered" role="document">
								<div class="modal-content">
								  <div class="modal-header">
									<h5 class="modal-title" id="longTitle">Please enter your information below:</h5>
									<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									  <span aria-hidden="true">&times;</span>
									</button>
								  </div>
								  <div id="modBod" class="modal-body">
									
											<p><b>Credit Card Type:</b></p>
											<br>
											<input name="Card" type="radio" checked="checked">
											<img height="50" src="logos/visaDebit.png"><br/>
											<input name="Card" type="radio">
											<img height="50" src="logos/masterCard.jpg"><br/>
											<input name="Card" type="radio">
											<img height="50" src="logos/americanExpress.png"><br/>
											<br/>
											<input id="cardNum" class="form-control mr-sm-2" type="number" placeholder="Enter your 12-digit card number" aria-label="Cardnumber" required>
											<br/>
											Expiry Year:
											<select required>
												<option selected="selected">2020</option>
												<option>2021</option>
												<option>2022</option>
												<option>2023</option>
												<option>2024</option>
												<option>2025</option>
											</select><br/>
											<br/>
											Expiry Month:
											<select required>
												<option selected="selected">January</option>
												<option>February</option>
												<option>March</option>
												<option>April</option>
												<option>May</option>
												<option>June</option>
												<option>July</option>
												<option>August</option>
												<option>September</option>
												<option>October</option>
												<option>November</option>
												<option>December</option>
											</select>
											<hr>
											<form align="center">
												<input type="text" id="secret" name="code" placeholder="Enter your secret code">
												<button type="button" onclick="discount()" id="disBut" class="btn btn-primary">Claim your discount</button><br><br>
											</form>
											<h3 id="totalModal"></h3>
								  </div>
								  <div id="modBut" class="modal-footer">
									<button type="button" onclick="concluded()" class="btn btn-primary jumboButton">Submit payment</button>
								  </div>
								</div>
							  </div>
							</div>
						<!-- Modal ends -->
		</div>

<!-- Here the footer starts -->
<footer>
	<div class="row text-center">
		<div class="col-md-2">
		<a href="#"><img id="backtotop" src="brandImages/footerImageUpsideDown.png" height="100" alt="Back to top" title="Back to top"></a>
		</div>
		<div id="footerPadding" class="col-md-5">
			<h5>© Copyright by Oliver Kovacevich Altaras - 2020</h5>
		</div>
		<div class="col-md-5">
		<h5>Keep in touch with us</h5>
		<br>
		<ul class="inlinelist">
		<li><a href="https://www.facebook.com/" class="fa fa-facebook"></a></li>
		<li><a href="https://twitter.com" class="fa fa-twitter"></a></li>
		<li><a href="https://www.youtube.com/" class="fa fa-youtube"></a></a></li>
		<li><a href="https://www.instagram.com/" class="fa fa-instagram"></a></li>
		<li><a href="https://www.snapchat.com/" class="fa fa-snapchat-ghost"></a></li>

		</ul>
		</div>
	</div>


</footer>




  
  
  

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
  <script>
  
  //creating a shortcut for DOM id function
  function $(x) {return document.getElementById(x);}
  
  
  var randomSlide = Math.ceil(Math.random() * 4);
  
   //creating a function to randomise the first image showing up on the carousel
  function randomise (){
	  if (randomSlide == 1){
	  $("slide1").className += " active";
	  } else if (randomSlide == 2){
		$("slide2").className += " active";
	  } else if (randomSlide == 3){
		$("slide3").className += " active";
	  } else {
		$("slide4").className += " active";
	  }
  }
  
  //Login function, including a function for when fields are empty. This function was created using a constructor and objects
  
  function login(){
		event.preventDefault();
		function Users (name, email, pass){
			this.name = name;
			this.email = email;
			this.pass = pass;
		}
		var userOliver = new Users("Oliver", "oliver@bestlast.com", "1234");
		var userEmer = new Users("Emer", "emer@bestlast.com", "4321");
		var uname = $("username").value;
		var pword = $("password").value;
			if (uname == userOliver.email && pword == userOliver.pass){
				alert ("You're now logged in, " + userOliver.name + "!");
				$("jumbotitle").innerHTML = "Time to shop, " + userOliver.name + "!";
				$("logbut").innerHTML = "Log out";
			} else if (uname == userEmer.email && pword == userEmer.pass){
				alert ("You're now logged in, " + userEmer.name + "!");
				$("jumbotitle").innerHTML = "Time to shop, " + userEmer.name + "!";
				$("logbut").innerHTML = "Log out";
			} else if (uname.length == 0 || pword.length == 0){
				alert ("Make sure no field is empty");
			}else {
				alert("We couldn't find you!");
			}
	}
  
  //creating javascript variables from php variables - product price
	var php1 = "<?php echo $row1['price']?>";
	var php2 = "<?php echo $row2['price']?>";
	var php3 = "<?php echo $row3['price']?>";
	var php4 = "<?php echo $row4['price']?>";
	var php5 = "<?php echo $row5['price']?>";
	
	//1st purchase button
  function buy1(){
	var qty = $("dropd1").value;
		if (qty == 1) {
		$("total1").innerHTML = 1*php1;
		$("amount1").innerHTML = qty;
		} else if (qty == 2) {
		$("total1").innerHTML = 2*php1;
		$("amount1").innerHTML = qty;
		} else if (qty == 3) {
		$("total1").innerHTML = 3*php1;
		$("amount1").innerHTML = qty;}
	showTotal();
  }
  
  //2nd purchase button 
  function buy2(){
	var qty = $("dropd2").value;
		if (qty == 1) {
		$("total2").innerHTML = 1*php2;
		$("amount2").innerHTML = qty;
		} else if (qty == 2) {
		$("total2").innerHTML = 2*php2;
		$("amount2").innerHTML = qty;
		} else if (qty == 3) {
		$("total2").innerHTML = 3*php2;
		$("amount2").innerHTML = qty;}
	showTotal();
  }
  
  //3rd purchase button  
  function buy3(){
	var qty = $("dropd3").value;
		if (qty == 1) {
		$("total3").innerHTML = 1*php3;
		$("amount3").innerHTML = qty;
		} else if (qty == 2) {
		$("total3").innerHTML = 2*php3;
		$("amount3").innerHTML = qty;
		} else if (qty == 3) {
		$("total3").innerHTML = 3*php3;
		$("amount3").innerHTML = qty;}
	showTotal();
  }
  
  //4th purchase button 
  function buy4(){
	var qty = $("dropd4").value;
		if (qty == 1) {
		$("total4").innerHTML = 1*php4;
		$("amount4").innerHTML = qty;
		} else if (qty == 2) {
		$("total4").innerHTML = 2*php4;
		$("amount4").innerHTML = qty;
		} else if (qty == 3) {
		$("total4").innerHTML = 3*php4;
		$("amount4").innerHTML = qty;}
	showTotal();
  }
  
  //5th purchase button
  function buy5(){
	var qty = $("dropd5").value;
		if (qty == 1) {
		$("total5").innerHTML = 1*php5;
		$("amount5").innerHTML = qty;
		} else if (qty == 2) {
		$("total5").innerHTML = 2*php5;
		$("amount5").innerHTML = qty;
		} else if (qty == 3) {
		$("total5").innerHTML = 3*php5;
		$("amount5").innerHTML = qty;}
	showTotal();
  }
  
  //this creates functions for the "clear" buttons
  function clearItem1(){
	  $("total1").innerHTML = 0;
	  $("amount1").innerHTML = 0;
	  showTotal();
  }
  
   function clearItem2(){
	  $("total2").innerHTML = 0;
	  $("amount2").innerHTML = 0;
	  showTotal();
  }
  
   function clearItem3(){
	  $("total3").innerHTML = 0;
	  $("amount3").innerHTML = 0;
	  showTotal();
  }
  
   function clearItem4(){
	  $("total4").innerHTML = 0;
	  $("amount4").innerHTML = 0;
	  showTotal();
  }
  
   function clearItem5(){
	  $("total5").innerHTML = 0;
	  $("amount5").innerHTML = 0;
	  showTotal();
  }
  
  
  
  
  //function to add all values - called when buttons above are pressed
	function showTotal(){
	  
  var t1 = $("total1").innerHTML;
  var t2 = $("total2").innerHTML;
  var t3 = $("total3").innerHTML;
  var t4 = $("total4").innerHTML;
  var t5 = $("total5").innerHTML;
  
  $("totalTotal").innerHTML = (t1*1 + t2*1 + t3*1 + t4*1 + t5*1).toFixed(2);
  $("totalModal").innerHTML = "Total due: €" + (t1*1 + t2*1 + t3*1 + t4*1 + t5*1).toFixed(2);
  }
  
  //function for a button that changes the body's background colour and the button's name and colour
  function goGreen() {
			$("tree").innerHTML = "Protect the environment!";
			$("tree").style.cssText = "background: green; color: white;";
			$("bodySpecs").style.background = "#28a745";
	}
	
  //function that allows comment to be written and posted on the website
  function comment(){
	event.preventDefault();
	var namePrompt = prompt("Please enter your name");
	$("suggestions").innerHTML = namePrompt + " says: " + "'" + $("comments").value + "'";	
  }
  
  //function that checks login details and whether the card number is valid. The login details use arrays
  function concluded(){
	  
	  var promone = prompt ("Please confirm your e-mail address: ");
	  var promtwo = prompt ("Please enter your password: ");
	  var users = ["oliver@bestlast.com", "emer@bestlast.com"];
	  var pass = ["1234", "4321"];
	  if ($("cardNum").value.length == 12){
		if ((promone == users[0] && promtwo == pass[0]) || (promone == users[1] && promtwo == pass[1])){
			$("modBod").style.color = "green";
			$("modBod").innerHTML = "<h4>Thank your for shopping with us. Your item(s) shall be delivered within 5 working days.</h4>";
			$("longTitle").style.visibility = "hidden";
			$("modBut").style.visibility = "hidden";
		} else {
			alert ("Oops, your login details are wrong!\n");
		} 
	  } else {
			 alert ("Invalid card information - Make sure you've entered all 12 numbers.\n");
	  }
  }
  
  //Code for the jumbotron guessing game
  function guessing (){
	event.preventDefault();
	var guessNum = Math.ceil(Math.random() * 30);
	for (i = 1; i < 4; i++){
		var attempt1 = prompt ("Guess a number from 1 to 30. You have " + (4 - i) + " attempts");
		if (attempt1 == guessNum){
			break;
		} else {
		alert ("Oops, incorrect... " + (3 - i) + " attempt(s) left");
		}
	}
	if (attempt1 == guessNum){
		alert ("You're a soothsayer! Here's a secret code to get €5 off: oka1989");
	} else {
		alert ("Sorry. It wasn't this time. The number was " + guessNum);
	  }
	  
  }
  
  //Code for the discount code generated on the guessing game
   function discount(){
	var disCode = $("secret").value;
		if (disCode == "oka1989"){
		$("totalModal").innerHTML = "Total due: €" + Number($("totalTotal").innerHTML - 5).toFixed(2);
		$("totalTotal").innerHTML = Number($("totalTotal").innerHTML - 5).toFixed(2);
		$("disBut").disabled = true;
		}else {
			alert("Invalid code");
		}
		
	}
  </script>
  
</html>