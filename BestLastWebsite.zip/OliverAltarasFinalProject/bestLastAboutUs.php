<!doctype html>
<html lang="en">
  <head>
	<link rel="icon" href="brandImages/icon.png" height="16">
	<!-- Icon library -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>Best Last - About Us</title>
	
	<style>
	
	.col-md-4 {
	padding-top: 80px;
	border: dashed 5px #28a745;
	}
	
	.navbar {
	opacity: 0.95;
	padding-right: 50px;
	}
	
	.btn {
	background-color: white;
	border: #28a745 solid;
	color: #28a745;
	}

	
	.fa {
	color: white;
	padding: 10px;
	font-size: 30px;
	text-align: center;
	text-decoration: none;
	margin: 5px 2px;
	}
	
	ul.inlinelist li {display: inline;}

	
	#talkToUs {padding-right: 100px;}
	
	#aboutUs {background-color: white;}
	
	#bodySpecs {background-color: #2F4F4F;}
	
	.titleAbout {
	color: #28a745;
	text-align: center;
	}
	
	.aboutImage {
	border: dashed 3px black;
	}
	
	#firstImage {
	border: dashed 3px #28a745;
	}
	
	#modalInfo {color: #28a745;}
	
	#footerPadding {
	padding-top: 70px;
	padding-bottom: 20px;
	}
	
	footer {
	border-top: solid 5px #2F4F4F;
	padding-top: 30px;
	background-color: #28a745;
	color: white;
	}

	</style>

  </head>
  <body id="bodySpecs">
  
				
  
  <!-- Here the navbar starts -->
  
<nav class="navbar navbar-expand-lg navbar-dark bg-success sticky-top">
	<a href="bestLastHomepage.php"><img src="brandImages/logoBL.png" height="80" alt="Logo - Best Last" title="bestlast.com"></a>
		<a class="navbar-brand" href="bestLastHomepage.php">&nbsp; Home</a>
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		  </button>
		  <div class="collapse navbar-collapse" id="navbarSupportedContent">
			<ul class="navbar-nav mr-auto">
			   <li class="nav-item">
        <a id="talkToUs" data-toggle="modal" data-target=".bd-example-modal-sm1" class="nav-link" href="">Talk to us</a>
				</li>
				<li>
				<button id="tree" onclick="goGreen()" class="btn btn-outline-success my-2 my-sm-0" type="submit" title="Environmental campaign">Go full green!</button>
				</li>
			</ul>
			<form class="form-inline my-2 my-lg-0">
			  <input id="username" class="form-control mr-sm-2" type="email" placeholder="Username" aria-label="Username" required>
			  <input id="password" class="form-control mr-sm-2" type="password" placeholder="Password" aria-label="Password" required>
			  <button id="logbut" onclick="login()" class="btn btn-outline-success my-2 my-sm-0" type="submit">Log in</button>
			</form>
		  </div>
</nav>

			<div class="col-lg-12">
				<br>
			</div>

<!-- Here the about us begins -->
<div class="container text-justify">
	<div id="aboutUs" class="row">
		<div class="col-md-8">
		<br>
		<h2 class="titleAbout" id="mainTitle">Welcome to the home of rejected gems</h2>
		<hr>
		<br>
		<p>Howdy there, fellow human being! You must be wondering what on Earth we were thinking when we came up with the idea of a website that sells trinkets long deemed unworthy of love.</p>
		
		<p>"Surely that's poor judgement, Best Last", you might tell us.</p>
		
		<p>We beg you to hold your horses, though. For we have one main reason to justify our actions. One main reason that goes beyond the appeal of guilty pleasures, the glamour of nostalgia and the allure of hoarding.</p>
		
		<p>And that reason, ladies and gentlemen, is simple: <i>recycling</i>. The recycling of culture that has been made by humans throughout the last 50 years or so.</p>
		
		<p>Ever since pop culture has become ubiquitous, people have been presented with both masterpieces and total disasters. But we believe that, just like your household waste, there is something in-between. Something that is not quite good, but that is good enough to be spared from the landfill.</p> 
		<p>We hope that by browsing through our products you might find something that captures your attention.</p>
		<hr>
		<h3 class="titleAbout">Try our green button</h3>
		<br>
		<p>Since we're all for recycling here, press the "Go full green!" button on the navigation bar above. Hopefully the complete viridescent look will remind you of the importance of recycling.</p>
		<p>Be it guilty pleasures of yore, be it all the waste you produce on a daily basis: recycle!</p>
		<br>
		<p class="titleAbout"><b>Thank you for visiting us!</b></p>
		</div>
		<div class="col-md-4">
		<a href="bestLastHomepage.php#productList"><img id="firstImage" src="aboutImages/aboutImage.png" alt="Start shopping now" class="img-fluid rounded-circle" title="Check out our range"></a>
		<br>
		<br>
		<br>
		<br>
		<a data-toggle="modal" data-target=".bd-example-modal-sm1" href=""><img src="aboutImages/aboutImage2.png" alt="Talk to us" class="img-fluid rounded-circle aboutImage" title="Contact us if you have any queries"></a>
		
				<!-- modal 1 code below -->
				<div class="modal fade bd-example-modal-sm1" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
				  <div class="modal-dialog modal-sm">
					<div class="modal-content">
						<img src="brandImages/icon.png" class="img-fluid">
						<h3 id="modalInfo" align="center">&nbsp;bestlast.com </h3>
						<p>&nbsp; Phone: 01 123 4567</P>
						<p>&nbsp; E-mail: info@bestlast.com</p>
						<p>&nbsp; Address: 12 Central Street, Dublin 89</p>
						<p>&nbsp; Dublin, Ireland</p>
					</div>
				  </div>
				</div>
				<!-- modal ends -->
		<br>
		<br>
		<br>
		<br>
		<a href="bestLastHomepage.php"><img src="aboutImages/aboutImage3.png" alt="Go back to homepage" class="img-fluid rounded-circle aboutImage" title="Back to homepage"></a>
				
				
				<br><br><br><br><br>
				<p>© Copyright by Oliver Kovacevich Altaras</p>
		</div>
		
	</div>
	


</div>

			<div class="col-lg-12">
				<br>
			</div>

<!-- Here the footer starts -->
<footer>
	<div class="row text-center">
		<div class="col-md-2">
		<a href="#"><img src="brandImages/footerImageUpsideDown.png" height="100" alt="Back to top" title="Back to top"></a>
		</div>
		<div id="footerPadding" class="col-md-5">
			<h5>© Copyright by Oliver Kovacevich Altaras - 2020</h5>
		</div>
		<div class="col-md-5">
		<h5>Keep in touch with us</h5>
		<br>
		<ul class="inlinelist">
		<li><a href="https://www.facebook.com/" class="fa fa-facebook"></a></li>
		<li><a href="https://twitter.com" class="fa fa-twitter"></a></li>
		<li><a href="https://www.youtube.com/" class="fa fa-youtube"></a></a></li>
		<li><a href="https://www.instagram.com/" class="fa fa-instagram"></a></li>
		<li><a href="https://www.snapchat.com/" class="fa fa-snapchat-ghost"></a></li>

		</ul>
		</div>
	</div>


</footer>


  
  
  

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>
	<script>
	
	//Login function, including a function for when fields are empty
	function login(){
		event.preventDefault();
		var users = ["oliver@bestlast.com", "emer@bestlast.com"];
		var pass = ["1234", "4321"];
		var uname = document.getElementById("username").value;
		var pword = document.getElementById("password").value;
			if (uname == users[0] && pword == pass[0]){
				alert ("You're now logged in, Oliver!");
				document.getElementById("mainTitle").innerHTML = "Welcome to our home, Oliver!";
				document.getElementById("logbut").innerHTML = "Log out";
			} else if (uname == users[1] && pword == pass[1]){
				alert ("You're now logged in, Emer!");
				document.getElementById("mainTitle").innerHTML = "Welcome to our home, Emer!";
				document.getElementById("logbut").innerHTML = "Log out";
			} else if (uname.length == 0 || pword.length == 0){
				alert ("One of the fields is empty");
			} else {
				alert("We couldn't find you!");
			}
	}
	
	//function for a button that changes the body's background colour and the button's name and colour
	function goGreen() {
			document.getElementById("tree").innerHTML = "Protect the environment!";
			document.getElementById("tree").style.cssText = "background: green; color: white;";
			document.getElementById("bodySpecs").style.background = "#28a745";
	}
	
	
	</script>
  
</html>